# SS2 — NMMR 904238 Sheet 02: georeference, digitisation, seam resolution

**Fundamental Data LLC — Ridgeline — Solar Site 2**
Evidentiary convention: **[W]** record fact · **[E]** derivation, method shown · **[O]** open variable

---

## 1. Headline

Sheet 02 of NMMR document 904238 is georeferenced, and mine areas 13, 14, 15 and 16 are digitised into EPSG:26917.

Handoff §16 item 2 — the seam attribution of Douglas #1 and Tub Run — is resolved:

- **Tub Run (Area 16) is Lower Kittanning.** Written out in full on the 1942 chart, and again on sheet 02. [W]
- **Douglas #1 (Area 14) is Upper Freeport.** Sheet 02 carries an explicit oval seam label reading "UF". The chart's "L.K." is a **ditto mark**, not an independent determination. Three independent lines agree. [W]/[E]

This does not enlarge the risk picture — it relocates it. The Long Run portals are Upper Freeport crop-line drifts into block #6, which is what handoff §7 anticipated as the failure mode of the severance argument.

---

## 2. Georeference [E]

Two independent registrations of sheet 02, both carried:

| Route | Control | Result |
|---|---|---|
| Graticule | 8 five-minute lines traced sub-pixel; corners self-labelled 79°45′/39°15′ NW and 79°30′/39°00′ SE | neatline aspect **+0.28%** vs cos(latitude) — inside the 0.6% criterion |
| Image tie | **3,884 SIFT control points** across the full sheet, tied to the original 1926 USGS quad | fit **rms 3.97 m**, mean 7.42 m, p95 14.75 m |

The two models diverge by mean 27.5 m / max 69.5 m across the sheet — paper distortion in the 1942 photographic copy of the 1926 base. **The image-tie model is adopted.** Coefficients in `sheet02_transform_poly2.npy` (2nd-order polynomial, sheet-02 pixel → EPSG:26917); control points in `sheet02_gcps.csv`.

Ground sample distance 7.93 m/px. Quad is Parsons 15′, polyconic, NAD27, per its own collar.

### Independent validation against modern-coordinate control [W]

Two WVGES underground outlines, digitised by WVGES from certified maps and already in modern coordinates, fall inside the corresponding digitised sheet-02 areas:

| WVGES outline | Area | Contained in |
|---|---|---|
| DOUGLAS NO 2, 1918, doc 327367 | 99.0 ac | **88.4%** inside sheet-02 Area 13 (Douglas #2) |
| TUB RUN NO 2, 1952, doc 340093 | 51.0 ac | **91.6%** inside sheet-02 Area 14 |

Both mines post- or pre-date the 1942 compilation and would be expected to sit inside the larger index area rather than fill it.

### Gotcha — packaged 1926/1908 district rasters carry an easting bias [W]

The 1926 GeoPDF (`WV_Parsons_253770_1926_62500_geo.pdf`, TNM) carries a TerraGo LGIDict georeference: polyconic, central meridian −79.625, origin latitude 39, datum NAS-A (NAD27). **The CTM's skew terms are spurious** — the true page-to-projection transform is a pure scale of **22.0486111 m per PDF point**, which is exactly 1:62,500 at 72 dpi, verified against pyproj at all four neatline corners to <0.3 m.

Registered that way and compared to the packaged district raster by SIFT (**4,351 inliers**, scatter ±2.0 m E / ±2.8 m N):

> `WV_Parsons_253770_1926_62500_geo_utm.tif` places features **+45.3 m too far west**.

`WV_Parsons_253768_1908_62500_geo_utm.tif` is likely affected the same way. The §3 dating conclusions turn on presence/absence over 100-acre polygons and do not move at 45 m, but any measurement taken off those rasters should be recomputed. The aspect check that was run on them (cos-latitude) cannot detect a translation.

---

## 3. What the numbered areas are — and are not [E]

Sheet 03's final column is headed **"Mine Area No."**, and sheet 02's numbered polygons are those mine areas. They are **index areas, not plans of workings.**

The arithmetic settles it. Area 14 is 1,585.2 ac. Upper Freeport net coal beneath the parcel is 60–84 in [W]; at 72 in and 80 lb/ft³ that is ~10,450 tons/acre in place, so Area 14 encloses ~16.6 M tons. Douglas #1 sampled **19,306 lb/day across 38 openings** in 1942 [W] — 9.65 tons/day, ~508 lb per opening per day, hand-loaded drift work. At that rate the enclosed tonnage represents **~5,700 years** of production.

Area 14 therefore delimits the ground indexed to the Douglas #1 opening group. It is **not** evidence that workings underlie the acreage it covers.

**[O] The extent of the Douglas #1 and Tub Run workings within their index areas remains the governing unknown.** Handoff §16 item 1 stands. No plan map was filed for either.

---

## 4. Seam resolution [W]/[E]

### 4.1 The chart entry for Douglas #1 is a ditto mark

Reading the coal-seam column against the mine-name column on sheet 03, row by row:

| Row | Mine name | Coal seam cell |
|---|---|---|
| 12 | #25 | **L.K.** written out |
| 13 | Douglas #2 | ditto |
| **14** | **Douglas #1** | **ditto** |
| 15 | Davis #27 | **U.F.** written out |
| 16 | **Tub Run** | **L.K.** written out |
| 17 | Finley Run | **Sew.** written out |

Rows 13 and 14 inherit L.K. from row 12 through a two-step ditto chain. Rows 15, 16 and 17 each break the chain with an explicit entry, so the compiler was writing the seam out whenever it changed. The chart's Lower Kittanning for Douglas #1 is an inherited default, not an assertion about that mine.

### 4.2 Sheet 02 labels Area 14 "UF"

Each numbered area carries a seam label in a hand-drawn oval, the same convention as the circled area numbers. Area 14's oval reads **"UF"**, beside the annotation "Doug. #1". Area 16 carries **"L.K."**

Fill colour does not encode seam — Area 12 is red and labelled "UF" while Area 16 is red and labelled "LK". The colours are adjacency map-colouring. The oval carries the attribute.

### 4.3 The extents corroborate the labels

Against the Upper Freeport erosional blocks:

| | On-parcel extent | On UF-present ground |
|---|---|---|
| **Area 14 (Douglas #1)** | 653.3 ac | **92.9%** |
| **Area 16 (Tub Run)** | 135.5 ac | **5.5%** |
| *parcel background* | 1,787.4 ac | *39.8%* |

Area 14 is enriched 2.3× over background and sits almost wholly on ground where the Upper Freeport survives; Area 16 sits almost wholly where it does not. The two areas' geometry matches their two different seam labels. Area 14 covers **81.6% of UF block #6**.

### 4.4 The portal geometry now resolves

Handoff §6 flagged an unresolved tension: the AML portals plot 400–795 m inby the Lower Kittanning crop, which fits a drift worked inby but not a collar. Against the digitised areas:

| Portal group | Relationship |
|---|---|
| Long Run (3 on-parcel, 1 off) | one **inside** Area 14; others **7 m, 40 m, 46 m** from it |
| Albert Highwall #1 (8 portals) | all **inside** Area 14 |
| Tub Run (2 on-parcel) | **61 m and 65 m** from Area 16 |

The tension dissolves under the Upper Freeport reading: these are crop-line collars on the Upper Freeport, and the 1942 register lumped them under an inherited seam entry. The alternative the handoff raised — "some openings are Upper Freeport crop-line drifts" — is the one the evidence supports.

---

## 5. Digitised areas — EPSG:26917

Two bases are carried for every polygon. The drawn outline is a heavy ink stroke ~6–8 px wide (~50–65 m at map scale); *inner* traces its inner edge, *centreline* dilates 3 px to the stroke centre. **Report the centreline basis; the pair brackets the digitising uncertainty.**

| Area | Mine | Seam | Basis | Total ac | On parcel ac | % of parcel |
|---|---|---|---|---|---|---|
| 14 | Douglas #1 | **U.F.** | centreline | 1,585.2 | **653.3** | 36.55% |
| 14 | Douglas #1 | U.F. | inner | 1,460.8 | 622.4 | 34.82% |
| 16 | Tub Run | **L.K.** | centreline | 179.1 | **135.5** | 7.58% |
| 16 | Tub Run | L.K. | inner | 137.5 | 105.0 | 5.87% |
| 15 | Davis #27 | U.F. | centreline | 1,110.9 | 0.0 | 0.00% |
| 13 | Douglas #2 | (ditto) | centreline | 302.9 | 0.0 | 0.00% |

Union of Areas 14 and 16 on the parcel: **788.9 ac (44.13%)** on the centreline basis, 727.4 ac (40.70%) inner.

Read this as index-area coverage, not undermined acreage — see §3.

---

## 6. What this changes for v2.0

The Lower Kittanning framing in handoff §0 and §6 rested on both mines being L.K. On the evidence here, **only Tub Run is.** For Solar Site 2 that means:

- The Lower Kittanning exposure narrows to **Area 16 / Tub Run**, 135.5 ac of index area on the parcel, 42 recorded openings, at 147 ft median cover.
- The Upper Freeport exposure is **Area 14 / Douglas #1**, 653.3 ac of index area, 71 recorded openings, inside block #6 at 83 ft median cover — driven in from block #6's own crop line, exactly the case §7 identified as not excluded by the severance argument.
- The §7 severance argument is **not** overturned. It never excluded entry from block #6's own crop, and that is what the Long Run and Albert Highwall portals are.

Cover depth cuts the other way between the two: 83 ft over the Upper Freeport ground is shallower than the 147 ft the Lower Kittanning framing assumed.

**Ratings discipline holds: net subsidence risk capped at LOW–MOD, no present-tense void asserted, "mapped legacy workings" throughout.**

---

## 7. Open items carried forward [O]

1. **Extent of workings inside Areas 14 and 16.** Unchanged and still governing. Index areas do not answer it.
2. **Sheet 01 is the next high-value analysis.** It plots **individual openings as points** on the same 1926 base, annotated with seam codes and circled counts. Digitising it would replace index-area coverage with actual opening locations. It needs its own georeference (different scan, 4600×4064).
3. **Recompute anything measured off the packaged 1926/1908 district rasters** against the +45.3 m easting bias.
4. AML project files WV000003 and WV002279; pre-1975 permit files for index numbers S-199 and 444 — requested, outstanding.
5. Historic aerial frames — selected, Lewis pulling.

---

## 8. Files

| File | Contents |
|---|---|
| `Ridgeline_SS2_sheet02_mine_areas.gpkg` | Areas 13/14/15/16, both bases, attributed with seam per sheet 02 and per chart, const. no., opening counts, on-parcel acreage, % on UF-present ground |
| `Ridgeline_SS2_NMMR904238_sheet02_geo_utm.tif` | Sheet 02 warped to EPSG:26917, 8 m, deflate, tiled |
| `sheet02_transform_poly2.npy` | 2nd-order polynomial, sheet-02 pixel → EPSG:26917 |
| `sheet02_gcps.csv` | 3,884 control points |
| `SS2_sheet02_findings.md` | this memo |

Reproduce the authoritative frame from `WV_Parsons_253770_1926_62500_geo.pdf` (TNM, Historical Topographic Maps): rasterise with `pdftoppm -r 300`, then page point → polyconic via `X = 22.0486111·xp − 13030.71099651742`, `Y = 22.0486111·yp − 2284.687357714342`, projection `+proj=poly +lat_0=39 +lon_0=-79.625 +datum=NAD27`, then transform to EPSG:26917. Do not use the LGIDict CTM's skew terms.

---

# Addendum — Sheet 01, and the record trail on Douglas #1

## A1. Sheet 01 georeferenced [E]

Same method, same authoritative frame.

| | Result |
|---|---|
| Graticule aspect | **+0.48%** vs cos(latitude) — inside the 0.6% criterion |
| Image tie | **11,687 SIFT control points**, fit **rms 4.08 m**, mean 8.16 m, p95 15.69 m |

Coefficients in `sheet01_transform_poly2.npy`; control points in `sheet01_gcps.csv`. Sheet 01 shares sheet 02's scan geometry, offset ~147 px in x.

## A2. Sheet 01 is a map-location index, not an opening inventory [W]

Sheet 01 carries **one filled-circle symbol per mine area**, each with a leader line and the area number, plus large circled seam counts (e.g. "2 Bw", "1 C"). These are the "MAP LOCATION — Hor./Vert." entries in the sheet-03 chart. It does **not** plot the 71 and 42 individual openings.

Twelve symbols detected cleanly. Four land inside the four digitised areas, one each:

| Symbol | Falls inside |
|---|---|
| E624,638 N4,332,026 — **on parcel** | **Area 16 (Tub Run)** |
| E627,668 N4,332,404 | **Area 14 (Douglas #1)** |
| E627,568 N4,332,826 | **Area 15 (Davis #27)** |
| E628,550 N4,331,209 | **Area 13 (Douglas #2)** |

Two independently georeferenced sheets, each placing its own symbol inside the matching digitised polygon, is a full cross-validation of both registrations and of the digitisation. Points in `Ridgeline_SS2_sheet01_map_locations.gpkg`.

## A3. Document 904239 does not cover this ground [W]

NMMR indexes doc **904239** as "Clark & Babcock", Lower Kittanning, 1942, LOCATION ONLY — the apparent Lower Kittanning companion to 904238. Retrieved and inspected: it is the **Davis quadrangle, edition of 1921**, covering the ground east of the Parsons sheet. Solar Site 2 lies west of its neatline. 904238 and 904239 are a **quadrangle pair, not a seam pair.**

Accordingly, no weight is placed on the NMMR index seam label for document 904238 as a whole.

## A4. The record trail on Douglas #1's seam [W]

The NMMR index is per mine record, not per document. Within doc 904238 it carries:

| Record | Seam in index |
|---|---|
| DOUGLAS #1 | **Lower Kittanning 08** |
| TUB RUN | Lower Kittanning 08 |
| DAVIS #24, #26, #27 | Davis 071 / Upper Freeport |

**The index entry for Douglas #1 is downstream of the 1942 chart** — the same chart whose seam cell for that row is a ditto mark. It is not independent corroboration of Lower Kittanning; it is the ditto mark propagated into a federal index.

State the discrepancy plainly in v2.0: the Upper Freeport reading rests on sheet 02's explicit oval label and on the extent geometry (§4.3), and it **differs from the seam recorded for Douglas #1 in the NMMR index.** That difference is a finding, not an error to be smoothed over.

### New target [O]

**Document 1007195** — a separate, earlier record (**1938**, Blackwater Coal Co) that also carries a DOUGLAS #1 entry with a seam attribution, predating the 1942 chart by four years. If its seam determination is independent, it settles the question either way.

It is **not** in the WVGES Mine Map Repository (`downloads.wvgs.wvnet.edu/minemaps/100/` returns 404 for all scenes of 1007195), so it is an OSMRE-held record. `mmr.osmre.gov` returns 503 from the sandbox. **Request it from the National Mine Map Repository by document number 1007195.** Its NMMR location assurance is LOW CONFIDENCE, so its plotted position is a county centroid and carries no spatial meaning — the value is in the seam column, not the location.

## A5. No plan map covers the parcel [W]

Querying the NMMR index across a 0.23° × 0.16° window returns 198 mine records. **Zero document footprints overlap Solar Site 2.** The nearest Upper Freeport underground map is TUB RUN #2 (doc 340093, 1952) at 13 m; then doc 340070 (Tub Run #1 / Cumberland #1, 1951) at 496 m, and docs 326861/326863/326864 (Cumberland #2, Douglas #3) at 523 m.

Handoff §16 item 1 stands unchanged: **no plan map was filed for Douglas #1 or Tub Run, and the extent of their workings remains the governing unknown.** The index areas digitised here bound where those workings may lie; they do not locate them.

## A6. Revised open items [O]

1. **Extent of the Douglas #1 and Tub Run workings.** Governing unknown. Unchanged.
2. **Document 1007195** — NMMR records request, for the 1938 seam attribution of Douglas #1. New, and the cheapest available test of §4.
3. **Recompute anything measured off the packaged 1926/1908 district rasters** — +45.3 m easting bias.
4. Docs 340070, 326861, 326863, 326864 (Upper Freeport, 496–523 m) — not yet examined, and now more relevant under the Upper Freeport reading than they were under Lower Kittanning.
5. AML project files WV000003 and WV002279; pre-1975 permit files for S-199 and 444 — requested, outstanding.
6. Historic aerial frames — selected, Lewis pulling. Under the Upper Freeport reading the 1956 and 1965 stereo pairs over the Long Run portal ground gain value: crop-line drift entries and their spoil should be visible.

**Closed this session:** sheet 02 georeference; sheet 01 georeference; seam attribution of Douglas #1 and Tub Run; the nature of the numbered areas; disposition of doc 904239.

## A7. Additional files

| File | Contents |
|---|---|
| `Ridgeline_SS2_sheet01_map_locations.gpkg` | 12 map-location symbols, EPSG:26917, with containing sheet-02 area and on-parcel flag |
| `sheet01_transform_poly2.npy` | 2nd-order polynomial, sheet-01 pixel → EPSG:26917 |
| `sheet01_gcps.csv` | 11,687 control points |

---

# Addendum 2 — Certified Upper Freeport workings on Long Run

## B1. Document 326863 — Douglas No. 3 Mine, Brown #4 Tract [W]

Retrieved from the WVGES Mine Map Repository (`minemaps/326/326863_01.jpg`). Certified plan, signed and notarised:

> **"Map of Proposed Heading, Cumberland Coal Co., Douglas No 3 Mine, Brown #4 Tract, Tucker Co., W. Va., Scale 1″=100′, May 1956, W. M. Linn C.E. No. 1704."** Certification covers the period ending 23 July 1956.

The sheet shows room-and-pillar entries, air courses, a **FAN**, a heading bearing **N 80° W**, an area annotated **"Worked Out"**, and the watercourse labelled **"LONG RUN"** running NW–SE through the sheet.

This is a **certified underground plan of Upper Freeport workings on Long Run** — the drainage that heads on Solar Site 2 and carries the three AML-inventoried portals on the parcel. NMMR indexes the document seam as Davis 071, which is Upper Freeport.

The companion sheet, **326864** (Douglas No. 3, April 1956), is the same mine on **Middle Creek**, with the coal annotated "Upper Freeport Coal" on the sheet face.

### Measured geometry [E]

Scale bar measured at **100 ft = 269.5 px → 0.1131 m/px**. The drawn workings envelope is **1,237 ft × 451 ft (377 m × 137 m)**, a bounding envelope of ~12.8 ac.

**Both sheets are "proposed heading" maps.** Each shows a single new heading plus the adjacent worked-out ground, not the mine as a whole. **[O] The full extent of Douglas No. 3 is not given by either sheet.**

### Why this matters

Under the Lower Kittanning reading, Upper Freeport maps in this district were peripheral. Under the Upper Freeport reading established in §4, a certified Cumberland Coal plan of Upper Freeport room-and-pillar workings **on Long Run** is directly on point. Douglas No. 1 (Area 14, 71 openings), Douglas No. 2, Douglas No. 3 and Cumberland No. 1/No. 2 are one operator's group working the same seam on the same drainage.

**[O] Georeference 326863.** It carries a north arrow and a measured scale bar but no graticule or coordinate grid, so registration must come from matching the drawn Long Run planform to the mapped stream. Both the authoritative 1926 Parsons quad and the 1 m LiDAR are available for that trace, and the three AML Long Run portals give independent check points. **This is the highest-value unfinished analysis.**

## B2. GeoMine location gotcha — blank assurance is not good assurance [W]

The handoff records that `locationassurance = LOW CONFIDENCE` records are dropped on the county centroid. A second failure mode is now documented:

> Documents **326861, 326863 and 326864** all carry a **blank** `locationassurance` and all plot at the **identical coordinate 39.12973, −79.52500**.

Documents 340070 (two records) likewise share one point. A blank assurance field therefore does **not** indicate a surveyed position — stacked identical coordinates are a nominal placement. The "523 m from the parcel" separation these documents appeared to have carries no spatial meaning, and no proximity conclusion should be drawn from GeoMine point geometry without checking for coordinate stacking first.

## B3. Service state this session [W]

- **OSMRE GeoMine** — working, and the productive entry point, as the handoff records.
- **WVGES Coal_Web_Mercator ArcGIS** (`atlas.wvgs.wvnet.edu`) — **503 throughout this session** over repeated attempts with backoff, on HTTP as required. Underground-outline queries by seam could not be run. `ug_near.gpkg` in the workspace remains the available substitute and already records zero WVGES underground outlines overlapping the parcel.
- **WVGES Mine Map Repository** (`downloads.wvgs.wvnet.edu/minemaps/`) — working, though intermittent 503s require retry with backoff. Retries succeed.
- **Overpass API** — 503, repeated attempts.
- **The National Map** — working; HTMC GeoPDFs retrieved.

## B4. Open items, revised again [O]

1. **Extent of the Douglas #1 and Tub Run workings.** Governing unknown.
2. **Georeference doc 326863** by Long Run planform matching — now the highest-value unfinished analysis, ahead of the aerial work. It places certified Upper Freeport workings against the parcel boundary directly.
3. **Document 1007195** — NMMR records request, for the independent 1938 seam attribution of Douglas #1.
4. **Re-run the WVGES underground-outline query by seam** when the atlas service returns, to confirm district-wide what is and is not digitised — in particular whether Douglas No. 3 is mapped at all.
5. **Recompute anything measured off the packaged 1926/1908 district rasters** — +45.3 m easting bias.
6. AML project files WV000003 and WV002279; pre-1975 permit files for S-199 and 444 — requested, outstanding.
7. Historic aerial frames — the 1956 and 1965 stereo pairs now coincide in date with the Douglas No. 3 certification (May 1956). The 1956 flight should show this operation live.

## B5. Additional files

Documents retrieved to the workspace and not previously held: `326863_01.jpg`, `326864_01.jpg` (Douglas No. 3), `904239_01/02/03.jpg` (Davis quadrangle, retained for district context though off-parcel).

---

# Addendum 3 — Long Run planform match on doc 326863

## C1. Method and control [E]

| Element | Value |
|---|---|
| Map scale | scale bar measured, **100 ft = 269.5 px → 0.1131 m/px** |
| Orientation | north arrow principal axis, elongation 35.2 — **9.66° from page vertical** |
| Map trace | north bank of the E–W reach (213 m) plus the SE reach recovered along a corridor, forming an L |
| Ground control | **1 m LiDAR**, `USGS_1M_17_x62y434_..._r1c1.tif` from the repo; sinks filled by priority flood (max raise 2.64 m), D8 flow accumulation, channel at >3,000 cells |

Search over translation on a 10 m grid with rotation swept 4–16°, scoring mean distance from the transformed trace to the channel network.

## C2. The planform match alone does not converge [E]

**This is a negative result and should be recorded as one.**

At the best rotation the minimum mean distance is 8.6 m, but **20 to 42 grid positions sit within 3 m of that minimum**, spread across an envelope of **E [626,240–627,810], N [4,331,350–4,332,430]** — roughly 1.6 km by 1.1 km. Re-running with an out-of-bounds penalty rather than index clipping did not change it, so this is genuine ambiguity, not an edge artefact.

The cause is the shape of the available signal. The drawn reach is 213 m of gently curving channel plus one bend, and Long Run's dendritic network offers many confluence bends of similar form at that scale. Seventy years of channel change and the planform fidelity of a hand-drawn 1″=100′ survey compound it.

**Doc 326863 is not georeferenced by stream planform alone.**

## C3. A provisional placement, and what it rests on [E]/[O]

One additional constraint discriminates among the near-optimal solutions. The map shows a **FAN** on the channel. Scoring each near-optimal solution by the distance from the transformed fan symbol to the nearest AML-inventoried opening:

| Rank | Stream fit | Fan → nearest AML opening | Origin |
|---|---|---|---|
| **1** | 11.4 m | **35 m** | E626,640 N4,332,210 |
| 2 | 11.5 m | 56 m | E626,600 N4,332,220 |
| 3 | 10.6 m | 228 m | E627,060 N4,332,060 |
| 4–8 | 10.2–11.6 m | 232–485 m | — |

Ranks 1 and 2 are the same solution (origins 40 m apart). The next cluster is six times further away. The nearest opening is a **Vertical Opening on Long Run** — and a fan serving a vertical opening is exactly the expected pairing, which is a physically sensible correspondence rather than a numerical coincidence.

Under that placement:

| | |
|---|---|
| Workings hull | **9.6 ac**, bounds E626,451–626,775 / N4,332,149–4,332,322 |
| Mapped FAN | E626,711 N4,332,141 |
| On Solar Site 2 | **0.0 ac** |
| Distance to parcel boundary | **32 m** |

**[O] This placement is provisional and must not be carried into a deliverable as established.** The tie-break rests on an assumed fan-to-opening correspondence, which is a hypothesis, not a record. And 32 m is well inside the placement uncertainty, so the correct statement is that **this mapped extent falls at the parcel boundary, on present evidence just outside it** — not that it is off the parcel. Written to `Ridgeline_SS2_326863_provisional.gpkg`, flagged provisional in the attributes.

What it does support, at the level the evidence allows: the Douglas No. 3 workings drawn on this sheet are **small — under 10 acres — and sit at the northern edge of the parcel**, not beneath its interior.

## C4. What would settle it

1. **The 1956 aerial frames.** AR1VMH000020025 and its stereo mate 20024 were flown **12 April 1956**; this sheet was certified for the period ending **23 July 1956**. The operation was live and leaf-off within weeks of the flight. A fan house, haul road, refuse pile and portal bench should be directly visible and would locate the mine outright, with no reliance on planform matching.
2. The 1959 Lead Mine 1:24,000 sheet, if it carries a mine symbol on this ground.
3. The AML project file for WV000003 Long Run, already requested.

---

# Addendum 4 — Aerial frames and camera calibration

## D1. What arrived [W]

Repo commit `da0b083` "SS2 Aerials" adds six files:

| File | Content |
|---|---|
| `1VMH000020025.tif.gz` / `1VMH000020024.tif.gz` | **1956 stereo pair**, 10,147 × 9,872 px, 8-bit greyscale, ~96 MB each uncompressed |
| `1VAWQ00010237.tif.gz` / `1VAWQ00010238.tif.gz` | **1965 stereo pair**, same nominal size |
| `Report_2_2_171349.pdf` | NBS calibration, C.P. Goerz Planigon lens No. 346, **28 May 1962** |
| `Report_2_2_179390-1.pdf` | NBS calibration, **Fairchild Cartographic Camera Type T-12 No. 53-118**, B&L Planigon lens No. XP6800, Abrams Aerial Survey Corp, **30 January 1964** |

## D2. Frame metadata verified from the film itself [W]

Frame **AR1VMH000020025** carries a legible data strip:

- Date **4-12-56** — matches the EarthExplorer record
- Frame **2-25**, project **GS-VMH**
- **CAL.F.L. 152.244 mm**
- Camera serial **53-118**

## D3. Camera assignment — and a calibration-epoch problem [W]/[E]

The serial on the film identifies the 1956 camera as **Fairchild T-12 No. 53-118** — the same camera as NBS report 2.2/179390-1. That report, however, is dated **January 1964**, eight years after the flight.

| Source | Calibrated focal length |
|---|---|
| Film data strip, in force at exposure, **1956** | **152.244 mm** |
| NBS report 179390-1, **1964** | 152.20 mm |

**Use 152.244 mm for the 1956 pair.** The 1964 report remains the source for the properties that do not drift: collimation marker separation **A–B 235.20 mm, C–D 235.23 mm** (A–B in the line of flight), principal point located to ±0.03 mm, radial distortion ≤3 µm average, tangential ≤3 µm. Both cameras are effectively distortion-free at the accuracy this work needs.

The second report (171349, Goerz Planigon No. 346, CFL **152.18 mm**, markers **A–B 222.43 / C–D 222.35 mm**) is a **different camera** — the marker separations differ by 13 mm, which is a decisive discriminator. Measuring fiducial separation on each scanned frame will assign the correct report per frame; that check has not yet been run on the 1965 pair.

**[O] No calibration contemporaneous with the 1956 flight is present.** The film stamp gives the focal length, which is the critical parameter, so this is a minor gap rather than a blocker.

## D4. Frame geometry [E]

At 1:31,000 with a 9-inch format across 10,147 px, scan resolution is ~22.5 µm/px and **ground sample distance ~0.70 m/px**, covering ~7.1 km square. That is ample to resolve a fan house, portal bench, haul road or refuse pile.

## D5. Contour strip mining imaged [W]

Bare-ground workings are clearly imaged near the centre of frame 20025 — arcuate highwall cuts following the contour, benches, cast-spoil lobes, and haul roads, in two connected lobes spanning roughly 1.3 km. The signature is unambiguous contour stripping and the imagery quality is excellent for interpretation.

**These particular scars do not match the Solar Site 2 disturbance envelope.** The SS2 envelope is a narrow sinuous corridor running ~2.3 km north–south along the western parcel, 200–300 m wide, in six polygons; the imaged lobes are two compact masses of different form. They are a different operation. This does not establish that the frame misses the parcel — one area of a 7 km frame was sampled — but it does mean **the frame footprint is not yet established and must not be assumed.**

## D6. Footprint determination — blocked, and the cheapest unblock [O]

Cross-modal SIFT between the 1956 film and a 2 m LiDAR hillshade **failed** (309 ratio matches, 24 inliers, degenerate transform). A 1956 leaf-off photograph and a 2018 shaded-relief surface do not share enough gradient structure. This is expected and is recorded so it is not retried blindly.

**The cheapest unblock is the EarthExplorer metadata you already hold.** The Aerial Photo Single Frames records carry a **frame centre latitude and longitude** for each entity ID. With centre coordinates for AR1VMH000020025 and 20024, the footprint is fixed immediately at ~7.1 km square and the georeference reduces to a well-posed local fit against the LiDAR road and stream network.

Failing that, the workable path is to segment every bare-ground scar across the full frame and match the resulting pattern to the LiDAR disturbance envelope — the SS2 corridor is distinctive enough to anchor it — but that is materially more work than reading four numbers off the EE record.

---

# Addendum 5 — Frame footprints, georeference, and focal-length reconciliation

## E1. Coverage confirmed [W]/[E]

EarthExplorer corner coordinates, reprojected to EPSG:26917 and intersected with the parcel:

| Frame | Date | Scale | AOI covered | Long Run openings | Disturbance envelope | Footprint |
|---|---|---|---|---|---|---|
| **AR1VMH000020025** | 1956/04/12 | 1:31,000 | **100.0%** | **5 of 5** | **100.0%** | 7.37 km |
| AR1VMH000020024 | 1956/04/12 | 1:31,000 | 63.3% | 5 of 5 | 55.6% | 7.37 km |
| AR1VAWQ00010237 | 1965/04/14 | 1:26,000 | 99.9% | 5 of 5 | 99.5% | 5.78 km |
| AR1VAWQ00010238 | 1965/04/14 | 1:26,000 | 99.8% | 5 of 5 | 98.6% | 5.78 km |

**Frame 20025 is the working frame** — full parcel, all openings, whole disturbance envelope. Frame 20024 is its stereo mate covering the northern 63%, and still carries all five Long Run openings, so the stereo model over the portal ground is intact. Footprints written to `Ridgeline_SS2_aerial_footprints.gpkg`.

Flying heights 15,500 ft (1956) and 13,000 ft (1965); format 229 × 229 mm; quality 8; cloud cover 0; stereo overlap 6 throughout.

## E2. Focal length — three sources reconciled [W]

| Flight | EarthExplorer | Film data strip | NBS report |
|---|---|---|---|
| **1956** (VMH00) | 152.23 mm | **152.244 mm** | 152.20 mm — report 179390-1, camera 53-118, **Jan 1964** |
| **1965** (VAWQ0) | **152.17 mm** | not yet read | **152.18 mm** — report 171349, Goerz Planigon No. 346, **May 1962** |

The 1965 EarthExplorer value (152.17 mm) matches report **171349** (152.18 mm) and not report 179390-1 (152.20 mm). **Report 171349 is the 1965 camera; report 179390-1 is the 1956 camera, recalibrated eight years after that flight.** The two are independently distinguishable by collimation marker separation — 222.43/222.35 mm for 171349 against 235.20/235.23 mm for 179390-1 — which remains the confirming check to run on the scans.

Adopt **152.244 mm** for the 1956 pair, from the film's own stamp at the exposure epoch, and **152.18 mm** for the 1965 pair.

## E3. Frame 20025 georeferenced to nominal accuracy [E]

Photo area located at x[600, 9555], y[392, 9360] — **8,955 × 8,968 px**, square as expected for a 229 mm format, giving ~25.6 µm/px scan resolution and **~0.79 m/px** ground sample distance. Projective transform fitted from the four EarthExplorer corners; warped to EPSG:26917 at 1 m and written to `Ridgeline_SS2_1956_frame20025_geo_utm.tif` (7,485 × 7,485).

**[O] This is a nominal georeference.** The EarthExplorer corners assume a vertical, north-up exposure with no relief correction, and the implied footprint (7,370 m) exceeds the format-and-scale figure (7,086 m) by 4%, so the stated scale is approximate. Expect errors of order 100–300 m.

An attempt to refine it by maximising bare-ground brightness inside the LiDAR disturbance envelope returned a shift of +364 m E / −100 m S. **That result is rejected** — it would push the eastern parcel boundary outside the film's image area, which contradicts the corner geometry. The optimiser found other bright ground (stream floodplain and off-parcel workings), not registration. Recorded so it is not repeated.

Refinement needs same-feature control: road intersections, stream confluences and bench edges identified in both the 1956 film and the LiDAR surface, fitted as GCPs.

## E4. First look at the Long Run portal ground [E]

An 1.8 km box centred on the Long Run openings (E626,740 N4,332,050), at nominal placement, shows forested and scrub terrain crossed by faint light-toned tracks and drainage lines, with possible old bench or road traces in the north-west quadrant.

**No tipple, fan house, refuse pile or fresh bare-ground bench is evident at this placement.** Given the ±100–300 m nominal uncertainty and the modest contrast, this is a first look and not a finding. It does not yet bear on the Douglas No. 3 placement in §C3, which needs the refined georeference.

Worth noting for interpretation: the long central disturbance corridor does not read as bare ground in April 1956, while the southern and north-eastern lobes of the envelope do. **This is consistent with the §3 dating bracket** — the Mozark Mountain southern strips are annotated on the 1968 sheet and not the 1959 one, so part of the 181.1 ac envelope post-dates this flight. The 1956 frame may therefore date the envelope internally, which is a result worth pursuing on its own once registration is firm.

## E5. Next steps [O]

1. **Refine the frame 20025 georeference** by same-feature GCPs against the LiDAR road and stream network — the gate on everything else.
2. **Read the 1965 frames' data strips** and measure fiducial separation on all four scans to confirm the camera assignment in §E2.
3. **Re-examine the Long Run ground** at refined registration for the Douglas No. 3 signature, then differencing the 1956 and 1965 epochs.
4. **Date the disturbance envelope internally** from the 1956 and 1965 bare-ground extents, which would tighten the §3 bracket beyond 1926–1968.
5. Build the stereo model from 20024/20025 at f = 152.244 mm for height extraction over the portal ground against the 2018 LiDAR.

---

# Addendum 6 — Attempt to refine the frame 20025 registration

## F1. The attempt, and why it failed [E]

Three automated routes were tried against the nominal EarthExplorer-corner georeference. **None succeeded.**

**Route 1 — bare ground against the disturbance envelope, whole-envelope.** Maximising mean brightness inside the LiDAR envelope returned +364 m E / −100 m N. Rejected on geometry.

**Route 2 — the same, per polygon.** Each of the six disturbance polygons was correlated separately, so that independent agreement could serve as the test. The six answers were dE/dN of (+244,+132), (−248,−204), (+112,−160), (+92,+228), (−212,−240), (+240,+176) — scattered to every quadrant, most pinned at the ±250 m search limit. **No consensus.** Each polygon simply found its nearest bright blob.

**Route 3 — LiDAR channel network against the bright floodplain.** Peak at +372 m E / −232 m N, peak-to-90th-percentile ratio 3.57.

Routes 1 and 3 agreed on direction, and that agreement was initially encouraging. **It is not evidence.** Both used the same local-contrast "bright ground" class, which covers **26.5%** of the frame:

| Local-contrast threshold | Bright fraction |
|---|---|
| >14 | 0.265 |
| >25 | 0.138 |
| >35 | 0.074 |
| >45 | 0.041 |

A class covering a quarter of the frame is leaf-off canopy and illumination variation, not bare ground. Correlating it against a 2.2% channel mask yields a weak, biased peak. Routes 1 and 3 share one bias, so their agreement is one result reported twice, not two. **The +370 m shift is not adopted.**

Visual overlay confirms the diagnosis: the channel network sits in dark linear valleys in both the nominal and shifted renderings, and the bright winding band that drove the correlation carries no mapped channel at all in either — it is not a stream.

## F2. Position [W]/[O]

**The nominal georeference stands**, unrefined, in `Ridgeline_SS2_1956_frame20025_geo_utm.tif`. Expected accuracy **±100–300 m**. It is sound for orientation, for locating a search window, and for scaling. It is **not** sufficient to place the Douglas No. 3 workings against the parcel boundary, where the question turns on 32 m.

Automated registration of this frame is closed as a route. **Refinement requires point GCPs picked on identifiable features** — road junctions, culvert and bridge crossings, bench ends — matched between the film and a LiDAR slope or curvature surface where road benches are resolvable. That is an interactive task, and the correct next step is to run it deliberately rather than to keep searching for a correlation signal that the imagery does not contain.

## F3. One finding that survives the uncertainty [E]

The long central disturbance corridor — 2.3 km north–south, the 90.0 ac polygon — **does not read as bare ground anywhere in the April 1956 frame**, while the southern and north-eastern lobes of the envelope do show bare ground nearby. At >45 local contrast the frame contains only 15 blobs larger than 0.64 ha across the whole AOI window; there is no 2 km sinuous bare scar anywhere in it.

A 300 m registration error cannot convert 2.3 km of continuous bare mine bench into closed canopy, so this observation is robust to the positional uncertainty in a way that the 32 m question is not.

**[E] Part of the 181.1 ac disturbance envelope post-dates April 1956.** This is consistent with §3, where the southern strips are annotated on the 1968 Mozark Mountain sheet and not on the 1959 Lead Mine sheet.

**[O] The envelope can be dated internally** by comparing bare-ground extent across the 1956, 1960, 1965 and 1973 frames, which would tighten the §3 bracket well inside 1926–1968. This needs only relative, not absolute, registration between frames of the same area — a materially easier problem than the absolute georeference, and worth taking first.

## F4. Revised next steps [O]

1. **Interactive GCP registration of frame 20025** — the gate on the Douglas No. 3 question.
2. **Epoch differencing of bare-ground extent** across 1956 / 1965 (and 1960, 1973 when pulled) to date the disturbance envelope internally. Achievable at relative registration; take this first.
3. Read the 1965 data strips and measure fiducial separations to confirm the §E2 camera assignment.
4. Stereo model from 20024/20025 at f = 152.244 mm over the portal ground, once registration is firm.

---

# Addendum 7 — Underground mining: subsidence, method, seam and working height

## G1. Mapped subsidence sits on Upper Freeport ground inside Area 14 [W]/[E]

The AML inventory's Subsidence polygon — **5.58 ac, entirely on Solar Site 2**, bounds E625,625–625,745 / N4,331,595–4,331,903 — was tested against seam presence and against the digitised mine areas:

| Test | Result |
|---|---|
| On Upper Freeport-present ground | **91.4%** (parcel background 39.8%) |
| Within UF erosional block **#6** | **91.4%** |
| Overlap with sheet-02 **Area 14 (Douglas #1)** | **46.8%**, distance 0 m |
| Overlap with Area 16 (Tub Run, Lower Kittanning) | 0.0%, distance **893 m** |

The feature is inventoried administratively under project **WV002279 "Tub Run Highwall and Refuse Phase III"**, but PAD numbers are problem-area groupings, not mine attributions — a feature can be inventoried under a neighbouring project. **The ground it occupies is Upper Freeport block #6, inside the Douglas #1 index area, and nearly 900 m from Tub Run.**

This is a **third line supporting the Upper Freeport reading in §4, and the strongest in kind**, because subsidence is a physical consequence of a void, located by field inventory rather than inherited through a records chain.

**It is also the first physical indication of mapped legacy workings beneath Solar Site 2.** The §7 seam-severance argument was never able to exclude entry into block #6 from its own crop line; this is what that looks like on the ground.

## G2. Morphology — trough, not crown hole [E]

1 m LiDAR over the polygon, against a 40 m-smoothed regional surface:

| | Inside polygon | Outside, same window |
|---|---|---|
| Mean residual | **−3.7 ft** | +0.2 ft |
| 10th percentile | −8.3 ft | −4.7 ft |
| Closed depressions ≥25 m², >0.15 m | **0** | 6, at 4.8 per 100 ac |

Cross-sections at three stations show a broad, flat-floored form in the southern two (edge-to-centre drop of 1.4 and 1.7 ft with residual minima of −7.8 and −5.0 ft), steepening to a valley form in the northern one.

**Broad open sag with no closed depressions is trough-style subsidence, not crown-hole or pit collapse.** That is the expected surface expression of progressive pillar yield over room-and-pillar workings, and it is consistent with the standing instruction to cap net subsidence risk at LOW–MOD.

**[O] A caution on the method.** A residual-from-smoothed-surface measure flags any negative anomaly, and a headwater hollow reads the same way. A channel does pass through the polygon (peak flow accumulation 2.1 ha), though channel cells occupy only 1.65% of it against 1.58% background, so the sag is materially wider than its drainage. The AML field classification as Subsidence is the record [W]; the morphometry above refines its character but does not independently prove origin.

## G3. Room-and-pillar is established, not inferred [W]

Doc **326863** is a certified plan showing **room-and-pillar workings directly** — parallel entries, crosscuts, air courses, rectangular pillars, a fan, and an area annotated "Worked Out." Pillars carry hand-lettered dimension annotations reading **80′**.

Three further lines agree:

- **Production scale.** Douglas #1 sampled 19,306 lb/day across 38 openings — ~508 lb per opening per day. That is hand-loaded drift work, which is room-and-pillar by construction.
- **Opening count.** 71 openings for Douglas #1 and 42 for Tub Run describe many small drift entries, not a concentrated face.
- **Era and district.** Longwall arrives in this district with Mettiki in the 1970s, decades after these operations.

**[O] Pillar dimensions are not yet reliably recoverable.** My scale-bar reading (100 ft = 269.5 px → 0.1131 m/px) puts the drawn pillar rectangles at 54–59 ft, against the sheet's own **80′** annotation — a mismatch of ~1.4× that I have not resolved. **Use the sheet's annotation, not my pixel measurement.** Resolving this needs the dimension arrows measured directly, and it matters, because extraction ratio drives subsidence potential.

## G4. Seam thickness and working height

**Seam [W]** — WVGES isopachs beneath the parcel: total bed **72–108 in (6.0–9.0 ft)**, net coal **60–84 in (5.0–7.0 ft)**.

**Working height [E]** — hand-loaded drift work takes the coal plus the minimum roof or floor needed for haulage clearance. Net coal alone gives 5.0–7.0 ft; the full bed including partings gives 6.0–9.0 ft; with 0–1 ft of take the plausible envelope is 5–10 ft. **Adopt 6–7 ft as the central case for the mined opening**, which is a little more than the seam, as expected.

**Cover [W]** — depth to the Upper Freeport: median **83 ft**, max 227 ft; 218.3 ac under 50 ft and 208.2 ac between 50 and 100 ft.

## G5. What the geometry implies [E]

Order-of-magnitude only, using extraction height × subsidence factor:

| Extraction | Pillars standing (0.10) | Partial yield (0.35) | Substantial failure (0.60) |
|---|---|---|---|
| 6 ft | 0.6 ft | 2.1 ft | 3.6 ft |
| 7 ft | 0.7 ft | 2.4 ft | 4.2 ft |

Full trough development needs a span of roughly 1.0–1.4 × cover: **83–116 ft at median cover**, 50–70 ft where cover is under 50 ft. Spans of that order are ordinary in room-and-pillar layouts, so trough subsidence is mechanically available at this site — as the mapped 5.58 ac demonstrates. The observed sag of 3.7–8.3 ft sits at or above the "substantial failure" end of the table, which is a further reason to treat the residual figure as an upper bound contaminated by natural relief rather than as a measured subsidence magnitude.

Shallow cover is the governing control on character. Where cover falls under about 50 ft, the failure mode shifts from broad trough toward localised collapse; **218.3 ac of the parcel carries less than 50 ft of cover to the Upper Freeport**, and that ground deserves separate treatment from the deeper 83 ft median.

## G6. Extent — still the governing unknown [O]

Nothing here bounds the extent of the workings. What is now established is that **workings exist beneath at least part of block #6**, evidenced by 5.58 ac of mapped subsidence, and that the method was room-and-pillar at a working height of about 6–7 ft under a median 83 ft of cover.

Priorities, revised:

1. **Resolve the pillar dimensions** on doc 326863 by measuring the dimension arrows. Extraction ratio is the single largest lever on subsidence potential and it is recoverable from a sheet already in hand.
2. **Map the sag systematically.** Run the residual-and-depression analysis over the whole of block #6 on the parcel, calibrated against off-block control ground, rather than only at the AML polygon. If further troughs of this form appear inside Area 14 and not outside it, that maps the workings by their surface expression — which is the only route to extent that does not depend on a plan map that was never filed.
3. **Sentinel-1 InSAR** to test whether any of this ground is moving now, as distinct from having moved historically.
4. Depth-of-cover split: treat the 218.3 ac under 50 ft separately from the deeper ground.

---

# Addendum 8 — Systematic sag mapping across Upper Freeport block #6

## H1. Method [E]

2 m LiDAR over the parcel and a 400 m buffer (1,628 × 2,577 cells). Sinks filled by priority flood with nodata cells seeded as outlets — **a first pass without that seeding produced artificial 200 m basins where the tile edge acted as a dam, and was discarded.** Derived: D8 flow accumulation, slope, and a residual surface (elevation minus a 40 m-sigma smoothed surface, in feet).

Comparison is restricted to an **interfluve mask** — slope under 10°, flow accumulation under 300 cells, and outside the mapped surface-mine disturbance — so that natural hollows, channels and strip benches do not drive the contrast. That leaves 2,305 ac of comparable ground.

Zones: **A** = block #6 ∩ Area 14, on parcel; **B** = block #6 on parcel outside Area 14; **C** = parcel where the Upper Freeport is eroded; **D** = block #6 off parcel; **E** = off parcel outside block #6.

## H2. Detector sensitivity, established against the known feature [E]

The 5.58 ac AML-mapped subsidence polygon is the positive control. **82.5% of it passes the interfluve filter**, and within it:

| Residual threshold | Inside AML subsidence | Whole window |
|---|---|---|
| < −3 ft | **54.6%** | 26.0% |
| < −5 ft | 29.7% | 16.4% |
| < −8 ft | 10.9% | 9.2% |

The detector recovers the known feature at roughly **2× enrichment at −3 ft**, falling to no contrast by −8 ft. **This is a weak-sensitivity detector, and the sensitivity is stated here so the negative result below is read at its true weight.** A trough as subtle as the mapped one could be missed elsewhere.

## H3. Result — no systematic sag over the implicated ground [E]

| Zone | ac | mean residual (ft) | p10 (ft) | < −6 ft | < −3 ft | closed depressions /100 ac |
|---|---|---|---|---|---|---|
| **A — block #6 ∩ Area 14, ON PARCEL** | **434** | **+0.78** | −3.62 | **3.5%** | **13.1%** | **1.2** |
| B — block #6 on parcel, outside Area 14 | 39 | +0.29 | −3.84 | 2.9% | 15.7% | 0.0 |
| C — parcel, Upper Freeport eroded (control) | 828 | −0.21 | −4.56 | 4.9% | 20.0% | 1.6 |
| D — block #6, off parcel | 202 | +2.92 | −3.12 | 3.4% | 10.6% | 5.4 |
| E — off parcel, outside block #6 (control) | 801 | −0.89 | −8.39 | 14.8% | 27.4% | 11.2 |
| *AML mapped subsidence (positive control)* | *5.6* | *−3.66* | *−8.27* | *20.9%* | *54.6%* | *0.0* |

**The ground indicated for Douglas #1 workings is the quietest in the analysis.** Zone A sits slightly convex on average, has the fewest closed depressions of any on-parcel zone, and is markedly quieter than both controls. Searching within Zone A for contiguous sag patches returns **zero at −5 ft** and **two totalling 3.3 ac at −3 ft**, out of 434 ac.

This reproduces, on the specific ground now implicated, the pattern already recorded in §3 — the parcel interior is less pitted than its surroundings.

Two distinct failure modes were tested and both are negative for Zone A. Closed-depression density tests for **crown holes and pit collapse**; note that this metric returns zero inside the AML polygon itself, so it is a crown-hole detector and not a trough detector. Mean residual and the sub-threshold fractions test for **troughs**; Zone A shows no trough signal.

## H4. What this does and does not establish

**Establishes [E]:** across 434 ac of Area 14 ground on Solar Site 2, there is no surface expression of subsidence at the sensitivity demonstrated in §H2. The 5.58 ac mapped locus is a **localised feature, not the visible edge of a widespread trough field.**

**Does not establish [O]:**

- **Absence of workings.** Room-and-pillar workings with pillars still standing produce little or no surface expression. §G5 puts sag at 0.6–0.7 ft with pillars intact — an order of magnitude below what this detector resolves. Quiet ground is consistent with workings present and stable, and equally with no workings at all. It does not discriminate between them.
- **Future stability.** These workings date from the 1940s–50s and any subsidence they were going to express at constant conditions has had seventy years to do so. That is reassuring for the past, not a guarantee against changes in loading or groundwater.
- **The shallow ground.** 218.3 ac of the parcel carries under 50 ft of cover to the Upper Freeport, where the failure mode shifts toward localised collapse rather than broad trough. That ground warrants its own treatment at higher detector sensitivity.

**Risk rating unchanged: net subsidence risk remains capped at LOW–MOD.** The evidence has moved on both sides — a physical indication of workings beneath the parcel in §G1, and an absence of widespread surface expression here — and the two together support the existing rating rather than displacing it.

## H5. Next [O]

1. **Sentinel-1 InSAR** over block #6. This is now the highest-value remaining test, and it answers the one question terrain morphology cannot: whether any of this ground is moving **now**, as opposed to having moved historically or not at all.
2. **Re-run at higher sensitivity over the 218.3 ac of sub-50 ft cover**, where crown-hole rather than trough behaviour governs and a finer detector is justified.
3. **Resolve pillar dimensions** on doc 326863 — extraction ratio remains the largest unquantified lever on subsidence potential.
4. Confirmation drilling on any structure sited over block #6, which is the disposition this analysis supports and does not replace.

Candidate sag loci written to `Ridgeline_SS2_sag_candidates_block6.gpkg` where any were found.

---

# Addendum 9 — Sentinel-1 InSAR feasibility over block #6

## I1. The archive [W]

ASF catalogue query on the parcel centroid, Sentinel-1 SLC, full mission to date:

| | |
|---|---|
| Scenes | **290**, on **288 unique dates**, 2015-03-15 to 2026-07-22 |
| Geometry | **ascending path 77, frame 122 — and nothing else** |
| Descending coverage | **none, across the entire mission** |
| Mode / polarisation | IW, VV+VH throughout |
| Revisit | median and modal **12 days**; largest gap 240 days |
| Leaf-off dates (Nov–Apr) | **145**, half the archive; 13–16 per year since 2017 |
| Leaf-off pairs at ≤12 days | **126** |

## I2. Terrain geometry — favourable [E]

Local incidence angle computed across the parcel from the 2 m LiDAR for a right-looking ascending pass at 39° incidence:

| | |
|---|---|
| Local incidence angle | median **39.0°**, p5 29.4°, p95 47.5° |
| Layover | **0.00%** of the parcel |
| Shadow | 0.01% |
| Severe foreshortening (<15°) | 0.12% |

The parcel is a gentle plateau, so the terrain imposes essentially no geometric penalty — unusual for Allegheny Front ground and a genuine point in favour.

Line-of-sight sensitivity to vertical motion is cos(39°) = **0.78**, so 1.0 ft of subsidence registers as 0.78 ft of LOS displacement. Serviceable.

## I3. The two problems

**Single geometry.** With ascending only and no descending anywhere in the archive, **vertical and horizontal motion cannot be separated.** Any result is line-of-sight and must be interpreted under an assumption of negligible horizontal movement. For broad trough subsidence that assumption is defensible; at trough edges, where horizontal strain is largest and where damage concentrates, it is weakest — precisely where one would most want the answer.

**Coherence.** This is the governing risk. C-band at 5.6 cm decorrelates over dense deciduous canopy within a single 12-day repeat in leaf-on season, and Solar Site 2 is undeveloped forest and revegetated mine land. Persistent-scatterer methods need built reflectors, and the parcel has essentially none — the AMD treatment infrastructure that would serve as scatterers sits on DS1 and DS2, not here. A distributed-scatterer approach restricted to the 145 leaf-off dates is the only realistic route, and even leaf-off coherence over mixed hardwood on this terrain is marginal rather than assured.

**[O] Canopy fraction over the parcel is not quantified.** MRLC returned 503 throughout this session, so NLCD tree canopy could not be retrieved. That figure is the single number that would firm up this assessment, and it should be obtained before any InSAR work is commissioned.

## I4. Assessment [E]

**InSAR over Solar Site 2 is a low-yield instrument, and this should be understood before it is commissioned rather than after.** The archive is deep and the terrain is cooperative, but the two limitations are structural: no descending pass exists to acquire, and forest decorrelation cannot be engineered away.

Set against §H, the case weakens further. That analysis found no surface expression of subsidence across 434 ac of the implicated ground, and the workings in question date from the 1940s–50s. InSAR measures present-day movement. The most probable outcome is a sparse, low-coherence result showing no significant motion — which would be consistent with §H but would not add to it, because a null over ground already quiet at the LiDAR is nearly uninformative.

The narrow case where it earns its cost is as a **screen for active movement at the 5.58 ac mapped locus** and along the sub-50 ft cover ground, where a positive detection would matter a great deal. A leaf-off SBAS stack targeted at those specific areas, rather than a parcel-wide survey, is the proportionate scope.

## I5. Better instruments for this question [O]

1. **Repeat LiDAR differencing.** A second epoch differenced against 2018 WV FEMAHQ D18 would measure vertical change directly, under canopy, at centimetre accuracy — everything InSAR cannot do here. **Whether a second epoch exists is unresolved: The National Map returned 504 on every attempt this session.** This is the first thing to check when the service returns, and if an epoch exists it supersedes the InSAR question entirely.
2. **Commissioned UAV LiDAR** over block #6 as a baseline, if no second public epoch exists. It establishes a monitoring datum on the ground that matters, at a cost far below a subsidence event.
3. **Survey monuments** over the 5.58 ac locus and the shallow-cover ground, read periodically. Unglamorous, cheap, and immune to every limitation above.
4. **Confirmation drilling** on any structure sited over block #6, which remains the disposition all of this analysis supports.

## I6. Service state this session

Working: OSMRE GeoMine; ASF catalogue API; WVGES Mine Map Repository (with retries).
Failing: **WVGES Coal_Web_Mercator** (503 throughout), **MRLC** (503), **The National Map** (504 on all lidar queries this session, though it served HTMC GeoPDFs earlier), Overpass (503).

---

# Addendum 10 — Search for an earlier LiDAR epoch

## J1. What exists [W]

The National Map API returned 504 on every lidar query this session, so the search was run directly against the USGS staged-products bucket, which listed successfully.

**Three 1 m projects exist for West Virginia:**

| Project | Covers Solar Site 2? |
|---|---|
| **WV_FEMAHQ_2018_D18** | **yes** — the tiles already in the repo |
| WV_FEMA_R3_East_2016 | **no** — its tiles in the x60–x62 columns stop at **y429**; the site is **y434** |
| WV_FEMAR3_Southcentral_2018_D19 | no |

Neighbouring-state projects (MD_Garret_Co_2014 among them) stop at the state line, 9.46 km north of the parcel.

**There is no second 1 m LiDAR epoch over Solar Site 2.**

One earlier elevation surface does exist: **`ned19_n39x25_w079x75_wv_statewide_2003`**, a 1/9 arc-second (~3 m) NED tile derived from West Virginia SAMB 2003. Retrieved and tested.

## J2. The 2003 surface is not fit for subsidence differencing [E]

Differenced against the 2018 LiDAR at 3 m, 2018 minus 2003, in feet:

| | |
|---|---|
| Median offset (datum/processing) | −2.60 ft, removed before analysis |
| **Point-to-point sd** | **±4.89 ft** |
| 1st–99th percentile spread | −14.8 to +12.0 ft |

Three diagnostics show the residual is artefact, not ground motion:

**The known subsidence appears to rise.** Over the 5.58 ac AML-mapped subsidence polygon the surface reads **+2.24 ft** between 2003 and 2018. Subsidence does not go up. Whatever this field measures over that ground, it is not elevation change.

**The error tracks slope.** Mean difference by slope class: +0.10 ft at 0–3°, −0.06 ft at 3–7°, −0.05 ft at 7–12°, **+0.59 ft at 12–20°, +1.31 ft above 20°**. The difference map shows red/blue dipoles paired along every drainage line and slope break — the signature of a small planimetric misregistration between the two surfaces, which produces opposite-signed error on opposing slopes.

**The zone pattern follows no geology.** Zone means split on-parcel versus off-parcel (−0.31 to −0.58 ft on parcel; +0.70 to +1.34 ft off it) across a boundary that is a property line, not a geological one.

Reported for completeness, but **these numbers should not be used**:

| Zone | ac | mean Δz (ft) |
|---|---|---|
| block #6 ∩ Area 14, on parcel | 540 | −0.31 |
| block #6 on parcel, outside Area 14 | 51 | −0.30 |
| parcel, UF eroded | 1,014 | −0.58 |
| block #6, off parcel | 292 | +1.34 |
| off parcel, outside block #6 | 1,515 | +0.70 |
| *AML mapped subsidence* | *5.0* | *+2.24* |

The between-zone spread of about 2 ft is the same order as the subsidence being looked for, and it is dominated by artefact. **A co-registration pass would suppress the slope-correlated component, but the residual canopy and photogrammetric noise at ±5 ft would still exceed the 0.6–4 ft signal from §G5.** The refinement is not worth commissioning.

## J3. Consequence

**No usable earlier epoch exists.** The 2018 LiDAR is the baseline, not the second observation.

That closes the cheapest route to measuring subsidence directly, and it changes the disposition of the earlier recommendations:

1. **Commissioned UAV LiDAR over block #6 rises to first place.** It establishes the second epoch that does not otherwise exist, under canopy, at the accuracy the question needs. Differenced against 2018 it would give a 7-plus year interval immediately, and it becomes more valuable with every year it is deferred.
2. **Survey monuments** over the 5.58 ac locus and the sub-50 ft cover ground remain the cheapest continuous check.
3. **InSAR** stays where §I4 left it — a targeted leaf-off screen at the mapped locus, not a parcel-wide survey, and now without a LiDAR cross-check to validate it against.
4. **Confirmation drilling** on any structure sited over block #6 remains the disposition all of this supports.

The three quantitative findings that stand on their own are unchanged: mapped subsidence sits on Upper Freeport ground inside Area 14 (§G1); there is no widespread surface expression of subsidence across 434 ac of that ground at the demonstrated detector sensitivity (§H3); and working height was about 6–7 ft under a median 83 ft of cover (§G4).
