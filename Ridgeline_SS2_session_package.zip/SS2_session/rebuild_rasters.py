#!/usr/bin/env python3
"""
Rebuild the two georeferenced rasters that are excluded from this package
because they are reproducible. Fundamental Data LLC - Ridgeline - Solar Site 2.

  1. Ridgeline_SS2_NMMR904238_sheet02_geo_utm.tif   (26 MB, 8 m, EPSG:26917)
  2. Ridgeline_SS2_1956_frame20025_geo_utm.tif      (45 MB, 1 m, EPSG:26917)

Inputs required (all already in the repo or in project knowledge):
  minemaps/904238_02.jpg          - SS2 handoff package
  1VMH000020025.tif.gz            - repo, commit da0b083
  transforms/sheet02_transform_poly2.npy
  transforms/sheet02_gcps.csv

Dependencies: pip install --break-system-packages rasterio opencv-python-headless pyproj numpy

Usage:  python3 rebuild_rasters.py sheet02 /path/to/904238_02.jpg
        python3 rebuild_rasters.py frame20025 /path/to/1VMH000020025.tif
"""
import sys, numpy as np, cv2, rasterio
from rasterio.transform import from_origin

HERE = __file__.rsplit("/", 1)[0]


def design(x, y):
    x = np.asarray(x, float); y = np.asarray(y, float)
    return np.column_stack([np.ones_like(x), x, y, x * x, x * y, y * y])


def sheet02(src_jpg, out="Ridgeline_SS2_NMMR904238_sheet02_geo_utm.tif", res=8.0):
    """Sheet 02 of NMMR 904238, warped by the 2nd-order polynomial fitted to
    3,884 SIFT GCPs tied to the USGS 1926 Parsons quad. Fit rms 3.97 m."""
    cE, cN = np.load(f"{HERE}/transforms/sheet02_transform_poly2.npy")
    G = np.loadtxt(f"{HERE}/transforms/sheet02_gcps.csv", delimiter=",", skiprows=1)
    B = design(G[:, 2] / 1000, G[:, 3] / 1000)
    rX = np.linalg.lstsq(B, G[:, 0], rcond=None)[0]
    rY = np.linalg.lstsq(B, G[:, 1], rcond=None)[0]

    src = cv2.imread(src_jpg)
    e0, e1, n0, n1 = 606500.0, 630500.0, 4316500.0, 4346500.0
    W, H = int((e1 - e0) / res), int((n1 - n0) / res)
    ee = e0 + (np.arange(W) + 0.5) * res

    prof = dict(driver="GTiff", height=H, width=W, count=3, dtype="uint8",
                crs="EPSG:26917", transform=from_origin(e0, n1, res, res),
                compress="deflate", tiled=True, blockxsize=256, blockysize=256)
    with rasterio.open(out, "w", **prof) as dst:
        for r0 in range(0, H, 512):
            r1 = min(r0 + 512, H)
            nn = n1 - (np.arange(r0, r1) + 0.5) * res
            EE, NN = np.meshgrid(ee, nn)
            Bg = design(EE.ravel() / 1000, NN.ravel() / 1000)
            mx = (Bg @ rX).reshape(r1 - r0, W).astype(np.float32)
            my = (Bg @ rY).reshape(r1 - r0, W).astype(np.float32)
            tile = cv2.remap(src, mx, my, cv2.INTER_LINEAR,
                             borderMode=cv2.BORDER_CONSTANT, borderValue=(255, 255, 255))
            win = rasterio.windows.Window(0, r0, W, r1 - r0)
            for i in range(3):
                dst.write(tile[:, :, 2 - i], i + 1, window=win)
    print("wrote", out)


def frame20025(src_tif, out="Ridgeline_SS2_1956_frame20025_geo_utm.tif", res=1.0):
    """1956 aerial frame AR1VMH000020025, projective transform from the four
    EarthExplorer corner coordinates.

    NOMINAL GEOREFERENCE ONLY - expect 100-300 m error. The EE corners assume a
    vertical, north-up exposure with no relief correction. See findings memo
    Addenda E3 and F. Do NOT use for questions turning on less than ~300 m.
    """
    from pyproj import Transformer
    t = Transformer.from_crs(4326, 26917, always_xy=True)
    # EE corners NW, NE, SE, SW (WGS84)
    ll = [(-79.602736, 39.156552), (-79.517485, 39.15657),
          (-79.517502, 39.090196), (-79.602673, 39.090178)]
    UTM = np.array([t.transform(*p) for p in ll])
    # photo area within the scan, detected by mean+std profile
    x0, x1, y0, y1 = 600, 9555, 392, 9360
    PX = np.float32([[x0, y0], [x1, y0], [x1, y1], [x0, y1]])
    Hm = cv2.getPerspectiveTransform(PX, np.float32(UTM))
    Hi = np.linalg.inv(Hm)

    src = rasterio.open(src_tif).read(1)
    E0, E1 = UTM[:, 0].min(), UTM[:, 0].max()
    N0, N1 = UTM[:, 1].min(), UTM[:, 1].max()
    W, H = int((E1 - E0) / res), int((N1 - N0) / res)
    ee = E0 + (np.arange(W) + 0.5) * res

    prof = dict(driver="GTiff", height=H, width=W, count=1, dtype="uint8",
                crs="EPSG:26917", transform=from_origin(E0, N1, res, res),
                compress="deflate", tiled=True, blockxsize=512, blockysize=512)
    with rasterio.open(out, "w", **prof) as dst:
        for r0 in range(0, H, 512):
            r1 = min(r0 + 512, H)
            nn = N1 - (np.arange(r0, r1) + 0.5) * res
            EE, NN = np.meshgrid(ee, nn)
            den = Hi[2, 0] * EE + Hi[2, 1] * NN + Hi[2, 2]
            mu = ((Hi[0, 0] * EE + Hi[0, 1] * NN + Hi[0, 2]) / den).astype(np.float32)
            mv = ((Hi[1, 0] * EE + Hi[1, 1] * NN + Hi[1, 2]) / den).astype(np.float32)
            dst.write(cv2.remap(src, mu, mv, cv2.INTER_LINEAR,
                                borderMode=cv2.BORDER_CONSTANT, borderValue=0),
                      1, window=rasterio.windows.Window(0, r0, W, r1 - r0))
    print("wrote", out)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(__doc__); sys.exit(1)
    {"sheet02": sheet02, "frame20025": frame20025}[sys.argv[1]](sys.argv[2])
