# SS2 session package — mine-index georeferencing, seam attribution, subsidence

**Fundamental Data LLC — Ridgeline — Solar Site 2, Tucker County, West Virginia**
CRS: **EPSG:26917** (NAD83 / UTM 17N) throughout. Elevations in feet where stated; DEM z is metres.

`SS2_sheet02_findings.md` is the governing record — ten addenda, with the evidentiary register [W] / [E] / [O] carried throughout. Read it before using anything here.

---

## Headline results

1. **Douglas #1 is Upper Freeport, not Lower Kittanning.** Sheet 02 of NMMR 904238 carries an explicit oval seam label "UF"; the 1942 chart's "L.K." is a ditto mark inheriting from two rows above; the extent geometry sits **92.9%** on Upper Freeport-present ground against a 39.8% parcel background. The NMMR index records Lower Kittanning, and that entry is the same ditto propagated into a federal index — the discrepancy is a finding, not an error to smooth over.
2. **The numbered areas are mine-index areas, not workings.** Area 14 encloses ~16.6 M tons; Douglas #1 sampled 9.65 tons/day. Read the on-parcel acreages as index coverage, never as undermined ground.
3. **Mapped subsidence sits on Upper Freeport ground inside Area 14** — 5.58 ac, entirely on the parcel, 91.4% within block #6, 893 m from Tub Run. First physical indication of mapped legacy workings beneath Solar Site 2.
4. **No widespread surface expression of subsidence** across 434 ac of that ground, at a detector calibrated against the known feature. Net subsidence risk remains capped at **LOW–MOD**.
5. **Room-and-pillar at a working height of about 6–7 ft** under a median 83 ft of cover, with 218.3 ac under 50 ft.

---

## Contents

### `vectors/` — EPSG:26917

| File | Contents |
|---|---|
| `Ridgeline_SS2_sheet02_mine_areas.gpkg` | Areas 13/14/15/16 from NMMR 904238 sheet 02. Two bases per polygon: *inner* traces the inner edge of the drawn ink stroke, *centreline* dilates 3 px to the stroke centre. **Report the centreline basis**; the pair brackets digitising uncertainty. Attributes carry seam per sheet 02 and per chart, const. no., opening counts, on-parcel acreage, % on UF-present ground. |
| `Ridgeline_SS2_sheet01_map_locations.gpkg` | 12 map-location symbols from sheet 01, with containing area and on-parcel flag. Four land inside Areas 13/14/15/16, one each — the cross-validation of both registrations. |
| `Ridgeline_SS2_aerial_footprints.gpkg` | Nominal footprints of the four aerial frames from EarthExplorer corners. |
| `Ridgeline_SS2_326863_provisional.gpkg` | **PROVISIONAL — do not carry into a deliverable.** Douglas No. 3 workings hull and fan, placed by stream planform plus an assumed fan-to-opening correspondence. The planform match alone does not converge (20 near-equal solutions). Flagged provisional in the attributes. See Addendum C3. |

### `transforms/`

Second-order polynomials, sheet pixel → EPSG:26917, with their control points.

| File | Fit |
|---|---|
| `sheet02_transform_poly2.npy` + `sheet02_gcps.csv` | 3,884 GCPs, rms **3.97 m** |
| `sheet01_transform_poly2.npy` + `sheet01_gcps.csv` | 11,687 GCPs, rms **4.08 m** |

Coefficient order is `[1, x, y, x², xy, y²]`, two rows: easting then northing.

### `minemaps/` — retrieved this session, not previously held

`326863_01.jpg`, `326864_01.jpg` — Cumberland Coal Co, **Douglas No. 3 Mine**, certified plans, 1″=100′, 1955 and 1956. 326863 is the **Brown #4 Tract on Long Run**; 326864 is Middle Creek, annotated "Upper Freeport Coal". Both are *proposed heading* maps showing one new heading plus adjacent worked-out ground — neither gives the mine's full extent.

`904239_01/02/03.jpg` — the apparent Lower Kittanning companion to 904238. It is the **Davis quadrangle, edition of 1921**, covering ground east of the Parsons sheet. **It does not cover Solar Site 2.** Retained for district context, and so nobody chases it again.

### `evidence/`

Crops supporting the findings memo: the frame 20025 data strip (CAL.F.L. 152.244 mm, camera 53-118), the contour stripping imaged in 1956, and the Long Run portal ground.

---

## Excluded, and how to rebuild

Two georeferenced rasters are omitted because they are reproducible — consistent with the existing convention of excluding rebuildable derivatives. Run `rebuild_rasters.py`:

```bash
pip install --break-system-packages rasterio opencv-python-headless pyproj numpy
python3 rebuild_rasters.py sheet02    /path/to/minemaps/904238_02.jpg
python3 rebuild_rasters.py frame20025 /path/to/1VMH000020025.tif
```

Also excluded, all retrievable from public sources:

| Item | Source |
|---|---|
| 1926 Parsons quad GeoPDF | `https://prd-tnm.s3.amazonaws.com/StagedProducts/Maps/HistoricalTopo/PDF/WV/62500/WV_Parsons_253770_1926_62500_geo.pdf` |
| 1926 quad raster | `pdftoppm -r 300 -jpeg WV_Parsons_253770_1926_62500_geo.pdf q26` |
| 2003 NED 1/9 arc-second | `https://prd-tnm.s3.amazonaws.com/StagedProducts/Elevation/19/IMG/ned19_n39x25_w079x75_wv_statewide_2003.zip` (192 MB) — **tested and rejected**, see below |

---

## Gotchas — hard-won, reuse these

**The packaged 1926/1908 district rasters carry a +45.3 m easting bias.** Measured against the USGS GeoPDF's own georeference by SIFT, 4,351 inliers, scatter ±2.0 m E / ±2.8 m N. The 1908 raster is likely affected the same way. A cos-latitude aspect check cannot detect a translation, so the check that was run on them does not catch this. Recompute anything measured off them.

**The 1926 GeoPDF's TerraGo CTM has spurious skew terms.** The true page-to-projection transform is a pure scale of **22.0486111 m per PDF point** — exactly 1:62,500 at 72 dpi — verified against pyproj at all four neatline corners to under 0.3 m. Projection is `+proj=poly +lat_0=39 +lon_0=-79.625 +datum=NAD27`, then transform to EPSG:26917. Do not use the CTM's b and c terms.

**Blank `locationassurance` in GeoMine is not good assurance.** Documents 326861, 326863 and 326864 all carry a blank field and all plot at the identical coordinate 39.12973, −79.52500. Doc 340070's two records likewise share one point. Check for coordinate stacking before drawing any proximity conclusion from GeoMine point geometry.

**Priority-flood sink filling must seed nodata as outlets.** A first pass without it produced artificial 200 m basins where the tile edge acted as a dam. Seed the queue from the border *and* from every valid cell adjacent to nodata.

**The 2003 NED is not fit for subsidence differencing.** Against 2018: point sd **±4.89 ft**, error tracks slope (+1.31 ft above 20°), and the known 5.58 ac subsidence polygon reads **+2.24 ft** — it appears to rise. Co-registration would suppress the slope-correlated part but residual canopy noise would still exceed the 0.6–4 ft signal. **There is no usable earlier LiDAR epoch:** of three WV 1 m projects, only WV_FEMAHQ_2018_D18 covers the site; WV_FEMA_R3_East_2016 stops at tile y429 and the site is y434.

**Routes closed — do not re-spend on these.** Automated registration of the 1956 frame (cross-modal SIFT against hillshade fails; bare-ground and channel correlations are dominated by a "bright" class covering 26% of the frame). Sheet 01 as an opening inventory — it is a map-location index, one symbol per area. InSAR as a parcel-wide survey: **ascending path 77 only, no descending anywhere in the mission**, and C-band decorrelates over deciduous canopy.

**Service state at time of writing.** Working: OSMRE GeoMine, ASF catalogue API, WVGES Mine Map Repository (retries needed), USGS staged-products S3 bucket. Failing: WVGES `Coal_Web_Mercator` (503 throughout), MRLC (503), The National Map lidar queries (504), Overpass (503).

---

## Open items

1. **Extent of the Douglas #1 and Tub Run workings** — the governing unknown. No plan map was filed for either.
2. **Pillar dimensions on doc 326863.** The sheet annotates **80′**; my scale-bar measurement puts the drawn rectangles at 54–59 ft, a ~1.4× mismatch I did not resolve. **Use the sheet's annotation.** Extraction ratio is the largest unquantified lever on subsidence potential.
3. **Document 1007195** — a separate 1938 record carrying its own Douglas #1 seam attribution, four years before the chart. Not in the WVGES repository; an OSMRE-held record requiring an NMMR request by document number. Its location assurance is LOW CONFIDENCE, so the value is in the seam column, not the position. **This is the one item that could reverse the seam finding.**
4. **UAV LiDAR baseline over block #6** — now the first-place monitoring recommendation, since no second public epoch exists and one differenced against 2018 gives a 7-plus year interval immediately.
5. AML project files WV000003 and WV002279; pre-1975 permit files for index numbers S-199 and 444 — requested, outstanding.
6. Canopy fraction over the parcel — MRLC unavailable; the one number that would firm up the InSAR assessment.
